void main() {
	printf('H');
    printf("hello world");
    int a = 0;
    if (a == 0) {
    	float b;
    	b = 1.1;
    }
	
	char c = 's';
	switch(c) {
		case 's':
			printf("hello world");
		case 'd':
			printf("hello");
			break;
		case 10:
			printf("char to int");
		default :
			printf("default");
			break;
	}
}
