//input test program

int x0 = 1;
float f0;
char c0 = '2';
char str[10];

void main() {
	printf(x0, c0, "\n");
	scanf(x0, f0, c0);
	printf(x0, f0, c0);
	scanf(x0);
	printf(x0);
}