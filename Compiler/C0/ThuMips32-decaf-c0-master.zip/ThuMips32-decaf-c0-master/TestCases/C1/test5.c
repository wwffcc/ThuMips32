void main() {
    char* s;
	s = (char*)malloc(10*sizeof(char));
    s = "\\\"\n";
    return 0;
}
