// This Program should trigger an "Integer Too Large Error"

void main() {
    int i;
    
    i = 73295739294;   // error!
    i = 3141592653;    // error too!
    
    float j;
    j = 7651561465.156464;
}