// This Program should trigger a "Syntax Error"

void main() {
	const int j = 0;
    int i = 0; // error! we don't support this grammer

    i = i + 1;
}