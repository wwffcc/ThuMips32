#define var "st
r"

int main() {
    char s;
	s = 'x
		';
    s = "str