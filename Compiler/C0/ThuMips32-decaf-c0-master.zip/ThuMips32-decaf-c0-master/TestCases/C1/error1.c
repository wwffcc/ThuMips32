// This Program should trigger an "Unrecognized Character Error"

void main() {
    int i;
    i = i @ -1; // error!
}