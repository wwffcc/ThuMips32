#define var 10

void main() {
	int a;
	a = 10;
	switch(a) {
	case 10:
		float x;
		x = 0.23;
		break;
	default:
		a = 34;
	}
	printf(a);
}
