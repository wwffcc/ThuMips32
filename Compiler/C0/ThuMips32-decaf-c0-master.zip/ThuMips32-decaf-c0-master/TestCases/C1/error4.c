void main() {
    char str;
    str = "string
	";
    str = 'xx';
    return 0;
}