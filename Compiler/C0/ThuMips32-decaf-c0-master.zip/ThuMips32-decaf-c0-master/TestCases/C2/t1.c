void main() {
	char c = 's';
	switch(c) {
		case 's':
			printf("hello world");
			break;
		case 'd':
			printf("hello");
			break;
		default :
			break;
	}
}
