void main() {
    if (true)
        break;
    int m;
	m = (int)true;
    return 1;
}