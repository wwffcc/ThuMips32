#define b "sdfds"
#define c 123.33

void main() {
	const int a = 10, d = 0;
	const bool e = true;
	char* f;
	a += 1;
	a = 1;
	a -= 1;
	d = d + a;
	c += a;
	b = "sdfs";
	b[2] = 's';
	b[3] = "sdfdf";
	e = false;
	f = "sdfsdfs";
	f = b;
}