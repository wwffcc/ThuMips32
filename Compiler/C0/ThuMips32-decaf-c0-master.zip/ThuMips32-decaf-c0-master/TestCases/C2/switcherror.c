void main() {
	float f = 123.3;
	switch(f) {
		case "sdfs":
			printf("hello world");
			break;
		case 12.222:
			printf("hello");
			break;
		default :
			break;
	}
}
